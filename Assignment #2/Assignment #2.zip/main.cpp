#include <iostream>

using namespace std; 


int main()
{
	int var1 = 0 , var2 = 0, var3 = 0;
	cin >> var1 >> var2 >> var3;
	
	cout << var1 << " " << var2 << " " << var3;
	return 0;
	}
